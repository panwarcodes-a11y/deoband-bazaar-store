# Deoband Bazar Storefront

Editable Instagram-friendly ecommerce storefront starter for `Deoband Bazar`, designed for an on-demand sourcing model.

## Files

- `index.html`: main storefront page and checkout UI
- `styles.css`: visual design and responsive layout
- `owner-edit/store-config.js`: business details, WhatsApp, Instagram, email, notes
- `owner-edit/store-products.js`: all product placeholders, prices, sizes, stock and descriptions
- `script.js`: product rendering, cart, modal, checkout and link handling
- `owner-edit/README-HINDI.txt`: simple Hindi guide for later edits

## What to customize first

1. Edit `owner-edit/store-config.js` with your brand details when ready.
2. Edit `owner-edit/store-products.js` to add your original products, prices, sizes, stock and descriptions.
3. Replace placeholder gradient values with actual product image URLs later.
4. Host this site on Netlify, Vercel, GitHub Pages or your own domain.
5. Connect Razorpay or Shopify if you want live online prepaid checkout.
6. If you do not keep stock, use `On Demand` status and update prices only when ready.

## Important note

This is a practical storefront starter with editable business/product files, cart and checkout details form. For live online payments, shipping labels, invoice generation and tracking, you still need Razorpay / Shopify / Shiprocket integration.
